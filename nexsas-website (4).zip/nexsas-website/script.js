  const menuBtn = document.getElementById('menuBtn');
  const mobileMenu = document.getElementById('mobileMenu');
  menuBtn.addEventListener('click', () => mobileMenu.classList.toggle('open'));
  document.querySelectorAll('.mobile-menu a:not([data-no-close])').forEach(a=>{
    a.addEventListener('click', ()=> mobileMenu.classList.remove('open'));
  });

  // Mobile accordion groups (Company / Platform / Resources)
  document.querySelectorAll('.m-group-btn').forEach(btn=>{
    btn.addEventListener('click', () => {
      const group = btn.closest('.m-group');
      const wasOpen = group.classList.contains('open');
      document.querySelectorAll('.m-group.open').forEach(g => g.classList.remove('open'));
      if (!wasOpen) group.classList.add('open');
    });
  });

  // Desktop nav dropdowns: click-to-toggle fallback (in addition to CSS hover)
  document.querySelectorAll('.nav-item').forEach(item=>{
    const btn = item.querySelector('button');
    if(!btn) return;
    btn.addEventListener('click', (e)=>{
      e.stopPropagation();
      const wasOpen = item.classList.contains('open');
      document.querySelectorAll('.nav-item.open').forEach(i => i.classList.remove('open'));
      if(!wasOpen) item.classList.add('open');
    });
  });
  document.addEventListener('click', ()=>{
    document.querySelectorAll('.nav-item.open').forEach(i => i.classList.remove('open'));
  });

  const themeToggle = document.getElementById('themeToggle');
  const themeIcon = document.getElementById('themeIcon');
  const sunPath = '<circle cx="12" cy="12" r="5"></circle><line x1="12" y1="1" x2="12" y2="3"></line><line x1="12" y1="21" x2="12" y2="23"></line><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line><line x1="1" y1="12" x2="3" y2="12"></line><line x1="21" y1="12" x2="23" y2="12"></line><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line>';
  const moonPath = '<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path>';

  function applyTheme(mode){
    document.documentElement.classList.toggle('dark', mode === 'dark');
    themeIcon.innerHTML = mode === 'dark' ? sunPath : moonPath;
  }
  const saved = localStorage.getItem('nexsas-theme') ||
    (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
  applyTheme(saved);

  themeToggle.addEventListener('click', () => {
    const isDark = document.documentElement.classList.contains('dark');
    const next = isDark ? 'light' : 'dark';
    applyTheme(next);
    localStorage.setItem('nexsas-theme', next);
  });

  // Pricing: billing toggle (monthly/yearly)
  const billingToggle = document.getElementById('billingToggle');
  if (billingToggle) {
    const labelMonthly = document.getElementById('labelMonthly');
    const labelYearly = document.getElementById('labelYearly');
    const priceMonthly = document.querySelectorAll('.price-monthly');
    const priceYearly = document.querySelectorAll('.price-yearly');
    billingToggle.addEventListener('click', () => {
      const isYear = billingToggle.classList.toggle('year');
      labelMonthly.classList.toggle('active', !isYear);
      labelYearly.classList.toggle('active', isYear);
      priceMonthly.forEach(el => el.style.display = isYear ? 'none' : '');
      priceYearly.forEach(el => el.style.display = isYear ? '' : 'none');
    });
  }

  // Pricing: FAQ accordion
  document.querySelectorAll('.faq-q').forEach(q => {
    q.addEventListener('click', () => {
      const item = q.closest('.faq-item');
      const wasOpen = item.classList.contains('open');
      document.querySelectorAll('.faq-item.open').forEach(i => i.classList.remove('open'));
      if (!wasOpen) item.classList.add('open');
    });
  });
